const $ = id => document.getElementById(id);

const end = new Date(Date.now() + 7*24*60*60*1000);
function updateTimer(){
  const diff = Math.max(0, end - Date.now());
  const s = Math.floor(diff/1000);
  $("days").textContent = String(Math.floor(s/86400)).padStart(2,"0");
  $("hours").textContent = String(Math.floor(s%86400/3600)).padStart(2,"0");
  $("minutes").textContent = String(Math.floor(s%3600/60)).padStart(2,"0");
  $("seconds").textContent = String(s%60).padStart(2,"0");
}
setInterval(updateTimer,1000); updateTimer();
$("year").textContent = new Date().getFullYear();

$("enterOffer").addEventListener("click", ()=>{
  window.open(
    "https://app.trcefy.com/click?pid=2&offer_id=22011&sub2=u513209&sub5=s1SUBID1HERE",
    "_blank",
    "noopener,noreferrer"
  );
});
